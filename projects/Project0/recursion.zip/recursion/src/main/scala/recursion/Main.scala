package recursion
import common._

object Main {

  /**
   * Exercise 1
   */
  def balance(chars: String): Boolean = ???

  /**
   * Exercise 2
   */
  def countChange(money: Int, coins: List[Int]): Int = ???
}
