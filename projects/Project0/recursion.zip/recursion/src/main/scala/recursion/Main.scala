package recfun
import common._

object Main {

  /**
   * Exercise 1
   */
  def balance(chars: List[Char]): Boolean = ???

  /**
   * Exercise 2
   */
  def countChange(money: Int, coins: List[Int]): Int = ???
}
